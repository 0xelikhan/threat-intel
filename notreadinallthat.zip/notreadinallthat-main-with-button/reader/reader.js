(async function () {
  "use strict";

  let PAGE_SIZE = parseInt(
    document.getElementById("page-size")?.value || "25",
    10,
  );
  const CONCURRENT_LIMIT = 5;

  let allEntries = [];
  let filteredEntries = [];
  let currentPage = 1;
  let sortNewestFirst = true;
  let visitedLinks = new Set();
  let disabledUrls = new Set();
  let refreshing = false;
  let refreshAbort = null;
  let enabledAiServices = [];

  const feedUrlInput = document.getElementById("feed-url");
  const addFeedBtn = document.getElementById("add-feed");
  const importOpmlBtn = document.getElementById("import-opml");
  const opmlFileInput = document.getElementById("opml-file");
  const refreshBtn = document.getElementById("refresh");
  const feedsSection = document.getElementById("feeds-section");
  const feedsToggle = document.getElementById("feeds-toggle");
  const feedsList = document.getElementById("feeds-list");
  const noFeedsMsg = document.getElementById("no-feeds");
  const enableAllBtn = document.getElementById("enable-all");
  const disableAllBtn = document.getElementById("disable-all");
  const exportOpmlBtn = document.getElementById("export-opml");
  const removeAllBtn = document.getElementById("remove-all");
  const searchInput = document.getElementById("search");
  const dateFromInput = document.getElementById("date-from");
  const dateToInput = document.getElementById("date-to");
  const clearDatesBtn = document.getElementById("clear-dates");
  const dedupeCheckbox = document.getElementById("dedupe");
  const pageSizeSelect = document.getElementById("page-size");
  const sortDateHeader = document.getElementById("sort-date");
  const entriesBody = document.getElementById("entries-body");
  const paginationTop = document.getElementById("pagination-top");
  const paginationBottom = document.getElementById("pagination-bottom");
  const footerEl = document.querySelector("footer");
  const statusBar = document.getElementById("status-bar");
  const progressFill = document.getElementById("progress-fill");
  const themeToggleBtn = document.getElementById("theme-toggle");
  const openAllBtn = document.getElementById("open-all-unread");
  const aiSelectToggle = document.getElementById("ai-select-toggle");
  const aiSelectDropdown = document.getElementById("ai-select-dropdown");
  const autoRefreshCheckbox = document.getElementById("auto-refresh");
  const autoRefreshIntervalInput = document.getElementById(
    "auto-refresh-interval",
  );

  const THEMES = ["light", "dark", "classic", "oled"];
  const THEME_ICONS = {
    light: "\u263E",
    dark: "\u2600",
    classic: "\u263E",
    oled: "\u2600",
  };

  const savedTheme = await browser.storage.local.get("theme");
  let currentTheme = savedTheme.theme || "light";
  if (!THEMES.includes(currentTheme)) currentTheme = "light";
  applyTheme(currentTheme);

  const feedsPanelOpen = await Storage.getFeedsPanelOpen();
  feedsSection.classList.toggle("collapsed", !feedsPanelOpen);

  themeToggleBtn.addEventListener("click", async () => {
    const idx = THEMES.indexOf(currentTheme);
    currentTheme = THEMES[(idx + 1) % THEMES.length];
    applyTheme(currentTheme);
    await browser.storage.local.set({ theme: currentTheme });
  });

  if (openAllBtn) {
    openAllBtn.addEventListener("click", async () => {
      const unreadEntries = getCurrentPageEntries().filter((entry) => {
        const normalized = entry._normalizedLink || normalizeLink(entry.link);
        return entry.link && normalized && !visitedLinks.has(normalized);
      });

      if (unreadEntries.length === 0) return;

      for (const entry of unreadEntries) {
        await browser.tabs.create({ url: entry.link, active: false });
        const normalized = entry._normalizedLink || normalizeLink(entry.link);
        if (normalized) {
          visitedLinks.add(normalized);
          await Storage.addVisitedLink(normalized);
        }
      }

      renderPage();
    });
  }

  function applyTheme(theme) {
    document.body.classList.remove("dark", "classic", "oled");
    if (theme !== "light") document.body.classList.add(theme);
    themeToggleBtn.textContent = THEME_ICONS[theme];
    themeToggleBtn.title = "Theme: " + theme;
  }

  enabledAiServices = await Storage.getEnabledAiServices();
  buildAiDropdown();

  aiSelectToggle.addEventListener("click", (e) => {
    e.stopPropagation();
    aiSelectDropdown.classList.toggle("open");
  });

  document.addEventListener("click", (e) => {
    if (!aiSelectDropdown.contains(e.target) && e.target !== aiSelectToggle) {
      aiSelectDropdown.classList.remove("open");
    }
  });

  function buildAiDropdown() {
    aiSelectDropdown.textContent = "";
    for (const svc of AI_SERVICES) {
      const label = document.createElement("label");
      label.className = "ai-option";
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.value = svc.id;
      cb.checked = enabledAiServices.includes(svc.id);
      cb.addEventListener("change", async () => {
        if (cb.checked) {
          if (!enabledAiServices.includes(svc.id))
            enabledAiServices.push(svc.id);
        } else {
          enabledAiServices = enabledAiServices.filter((id) => id !== svc.id);
        }
        await Storage.saveEnabledAiServices(enabledAiServices);
        renderPage();
      });
      label.appendChild(cb);
      label.appendChild(document.createTextNode(" " + svc.label));
      aiSelectDropdown.appendChild(label);
    }
  }

  function toLocalDatetimeString(date) {
    const pad = (n) => String(n).padStart(2, "0");
    return (
      date.getFullYear() +
      "-" +
      pad(date.getMonth() + 1) +
      "-" +
      pad(date.getDate()) +
      "T" +
      pad(date.getHours()) +
      ":" +
      pad(date.getMinutes())
    );
  }
  const now = new Date();
  const threeDaysAgo = new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000);
  const oneDayAhead = new Date(now.getTime() + 1 * 24 * 60 * 60 * 1000);
  dateFromInput.value = toLocalDatetimeString(threeDaysAgo);
  dateToInput.value = toLocalDatetimeString(oneDayAhead);

  const autoRefreshSettings = await Storage.getAutoRefresh();
  autoRefreshCheckbox.checked = autoRefreshSettings.enabled;
  autoRefreshIntervalInput.value = autoRefreshSettings.intervalMinutes;

  autoRefreshCheckbox.addEventListener("change", async () => {
    const settings = await Storage.getAutoRefresh();
    settings.enabled = autoRefreshCheckbox.checked;
    await Storage.saveAutoRefresh(settings);
    browser.runtime.sendMessage({ type: "auto-refresh-changed" });
  });

  autoRefreshIntervalInput.addEventListener("change", async () => {
    let val = parseInt(autoRefreshIntervalInput.value, 10);
    if (!val || val < 1) {
      val = 1;
      autoRefreshIntervalInput.value = 1;
    }
    const settings = await Storage.getAutoRefresh();
    settings.intervalMinutes = val;
    await Storage.saveAutoRefresh(settings);
    browser.runtime.sendMessage({ type: "auto-refresh-changed" });
  });

  async function updateDisabledUrls() {
    const feeds = await Storage.getFeeds();
    disabledUrls = new Set(
      feeds.filter((f) => f.enabled === false).map((f) => f.url),
    );
  }

  function stampNormalizedLinks(entries) {
    for (const entry of entries) {
      if (!entry._normalizedLink) {
        entry._normalizedLink = normalizeLink(entry.link);
      }
    }
  }

  entriesBody.addEventListener("click", (e) => {
    const a = e.target.closest("a.entry-link");
    if (!a) return;
    const normalized = a.dataset.normalized;
    if (normalized) {
      visitedLinks.add(normalized);
      a.closest("tr").className = "visited";
      Storage.addVisitedLink(normalized);
    }
  });

  function onPaginationClick(e) {
    const btn = e.target.closest("button[data-page]");
    if (!btn) return;
    currentPage = parseInt(btn.dataset.page, 10);
    renderPage();
    window.scrollTo(0, 0);
  }
  paginationTop.addEventListener("click", onPaginationClick);
  paginationBottom.addEventListener("click", onPaginationClick);

  setStatus("Loading cached entries...");
  visitedLinks = await Storage.getVisitedLinks();
  allEntries = await Storage.getCachedEntries();
  stampNormalizedLinks(allEntries);
  await updateDisabledUrls();
  applyFilter();
  await renderFeedsList();
  setStatus("Ready - " + allEntries.length + " entries loaded from cache");
  refreshAllFeeds();

  browser.runtime.onMessage.addListener((message) => {
    if (message.type !== "background-refresh-done" || refreshing) {
      return false;
    }

    void (async () => {
      allEntries = await Storage.getCachedEntries();
      stampNormalizedLinks(allEntries);
      await updateDisabledUrls();
      sortEntries();
      applyFilter();
      setStatus("Auto-refreshed - " + allEntries.length + " entries");
    })().catch((err) => {
      console.error("Reader: failed to apply background refresh: " + err.message);
    });

    return false;
  });

  feedsToggle.addEventListener("click", async () => {
    const isOpen = feedsSection.classList.contains("collapsed");
    feedsSection.classList.toggle("collapsed", !isOpen);
    await Storage.saveFeedsPanelOpen(isOpen);
  });

  enableAllBtn.addEventListener("click", async () => {
    await Storage.setAllFeedsEnabled(true);
    await updateDisabledUrls();
    await renderFeedsList();
    applyFilter();
  });

  disableAllBtn.addEventListener("click", async () => {
    await Storage.setAllFeedsEnabled(false);
    await updateDisabledUrls();
    await renderFeedsList();
    applyFilter();
  });

  exportOpmlBtn.addEventListener("click", onExportOpml);

  removeAllBtn.addEventListener("click", async () => {
    if (!confirm("Are you sure you want to remove all feeds?")) return;
    if (
      !confirm(
        "This will permanently delete all feeds and cached entries. Continue?",
      )
    )
      return;
    await Storage.removeAllFeeds();
    allEntries = [];
    await updateDisabledUrls();
    await renderFeedsList();
    applyFilter();
  });

  addFeedBtn.addEventListener("click", onAddFeed);
  feedUrlInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") onAddFeed();
  });
  importOpmlBtn.addEventListener("click", () => opmlFileInput.click());
  opmlFileInput.addEventListener("change", onImportOpml);
  refreshBtn.addEventListener("click", () => {
    if (refreshing) {
      if (refreshAbort) refreshAbort.abort();
    } else {
      refreshAllFeeds();
    }
  });

  let searchTimer = null;
  searchInput.addEventListener("input", () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
      currentPage = 1;
      applyFilter();
    }, 250);
  });

  dateFromInput.addEventListener("change", () => {
    currentPage = 1;
    applyFilter();
  });
  dateToInput.addEventListener("change", () => {
    currentPage = 1;
    applyFilter();
  });
  clearDatesBtn.addEventListener("click", () => {
    dateFromInput.value = "";
    dateToInput.value = "";
    currentPage = 1;
    applyFilter();
  });

  dedupeCheckbox.addEventListener("change", () => {
    currentPage = 1;
    applyFilter();
  });

  pageSizeSelect.addEventListener("change", () => {
    PAGE_SIZE = parseInt(pageSizeSelect.value, 10);
    currentPage = 1;
    renderPage();
  });

  sortDateHeader.addEventListener("click", () => {
    sortNewestFirst = !sortNewestFirst;
    sortDateHeader.querySelector(".sort-arrow").textContent = sortNewestFirst
      ? "\u25BC"
      : "\u25B2";
    currentPage = 1;
    sortEntries();
    applyFilter();
  });

  async function onAddFeed() {
    const url = feedUrlInput.value.trim();
    if (!url) return;

    try {
      new URL(url);
    } catch {
      setStatus("Invalid URL");
      return;
    }

    setStatus("Adding feed...");
    const added = await Storage.addFeed(url);
    if (!added) {
      setStatus("Feed already exists");
      return;
    }

    feedUrlInput.value = "";
    await updateDisabledUrls();
    await renderFeedsList();

    const newEntries = await fetchFeed(url);
    if (newEntries.length > 0) {
      mergeEntries(newEntries);
      await Storage.saveCachedEntries(allEntries);
      applyFilter();
    }
    setStatus("Added feed - " + allEntries.length + " total entries");
  }

  async function onExportOpml() {
    const feeds = await Storage.getFeeds();
    if (feeds.length === 0) {
      setStatus("No feeds to export");
      return;
    }

    try {
      const opml = OpmlParser.stringify(feeds, "Not Readin' All That Feeds");
      const blob = new Blob([opml], {
        type: "text/x-opml;charset=utf-8",
      });
      const objectUrl = URL.createObjectURL(blob);
      const link = document.createElement("a");
      const date = new Date().toISOString().slice(0, 10);

      link.href = objectUrl;
      link.download = "notreadinallthat-feeds-" + date + ".opml";
      link.hidden = true;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);

      setStatus("Exported " + feeds.length + " feeds to OPML");
    } catch (err) {
      setStatus("OPML export error: " + err.message);
    }
  }

  async function onImportOpml() {
    const file = opmlFileInput.files[0];
    if (!file) return;

    setStatus("Importing OPML...");
    try {
      const text = await readFileAsText(file);
      const feeds = OpmlParser.parse(text);

      if (feeds.length === 0) {
        setStatus("No feeds found in OPML file");
        return;
      }

      let addedCount = 0;
      for (const feed of feeds) {
        const added = await Storage.addFeed(feed.url, feed.title);
        if (added) addedCount++;
      }

      await updateDisabledUrls();
      await renderFeedsList();
      setStatus("Imported " + addedCount + " new feeds - refreshing...");
      await refreshAllFeeds();
    } catch (err) {
      setStatus("OPML import error: " + err.message);
    }

    opmlFileInput.value = "";
  }

  let hideTimer = null;

  async function refreshAllFeeds() {
    if (refreshing) return;

    const feeds = await Storage.getFeeds();
    if (feeds.length === 0) {
      return;
    }

    refreshing = true;
    refreshAbort = new AbortController();
    refreshBtn.textContent = "Stop";

    const enabledFeeds = feeds.filter((f) => f.enabled !== false);
    const total = enabledFeeds.length;
    let completed = 0;

    clearTimeout(hideTimer);
    footerEl.classList.add("active");
    setProgress(0);
    setStatus("Refreshing 0/" + total + " feeds...");

    const urls = enabledFeeds.map((f) => f.url);
    const activeUrls = new Set();

    const newEntries = await fetchFeedsBatched(
      urls,
      (url, phase) => {
        if (phase === "start") {
          activeUrls.add(url);
        } else {
          activeUrls.delete(url);
          completed++;
          setProgress(completed / total);
        }
        const current =
          activeUrls.size > 0 ? " (" + [...activeUrls].join(", ") + ")" : "";
        setStatus(
          "Refreshing " + completed + "/" + total + " feeds..." + current,
        );
      },
      refreshAbort.signal,
    );

    const cancelled = refreshAbort.signal.aborted;

    allEntries = [];
    mergeEntries(newEntries);
    await Storage.saveCachedEntries(allEntries);
    await updateDisabledUrls();
    applyFilter();

    if (cancelled) {
      setStatus(
        "Stopped - " +
          allEntries.length +
          " entries from " +
          completed +
          "/" +
          total +
          " feeds",
      );
    } else {
      setProgress(1);
      setStatus(
        "Refreshed - " +
          allEntries.length +
          " entries from " +
          total +
          " feeds",
      );
    }

    refreshing = false;
    refreshAbort = null;
    refreshBtn.textContent = "Refresh";

    hideTimer = setTimeout(() => {
      footerEl.classList.remove("active");
    }, 3000);
  }

  async function fetchFeed(url, signal) {
    try {
      const resp = await fetch(url, { signal });
      if (!resp.ok) throw new Error("HTTP " + resp.status);
      const text = await resp.text();
      return FeedParser.parse(text, url);
    } catch (err) {
      if (err.name === "AbortError") return [];
      console.warn("Failed to fetch " + url + ": " + err.message);
      return [];
    }
  }

  async function fetchFeedsBatched(urls, onFeedEvent, signal) {
    const results = [];
    for (let i = 0; i < urls.length; i += CONCURRENT_LIMIT) {
      if (signal && signal.aborted) break;
      const batch = urls.slice(i, i + CONCURRENT_LIMIT);
      const batchResults = await Promise.allSettled(
        batch.map((url) => {
          if (onFeedEvent) onFeedEvent(url, "start");
          return fetchFeed(url, signal).then((entries) => {
            if (onFeedEvent) onFeedEvent(url, "done");
            return entries;
          });
        }),
      );
      for (const r of batchResults) {
        if (r.status === "fulfilled") {
          results.push(...r.value);
        }
      }
    }
    return results;
  }

  function normalizeLink(link) {
    if (!link) return "";
    try {
      const u = new URL(link);
      u.hash = "";
      for (const p of [
        "utm_source",
        "utm_medium",
        "utm_campaign",
        "utm_term",
        "utm_content",
      ]) {
        u.searchParams.delete(p);
      }
      return u.toString().replace(/\/+$/, "").toLowerCase();
    } catch {
      return link.trim().replace(/\/+$/, "").toLowerCase();
    }
  }

  function sortEntries() {
    allEntries.sort((a, b) => {
      if (!a.pubDate && !b.pubDate) return 0;
      if (!a.pubDate) return 1;
      if (!b.pubDate) return -1;
      const cmp = a.pubDate.localeCompare(b.pubDate);
      return sortNewestFirst ? -cmp : cmp;
    });
  }

  function mergeEntries(newEntries) {
    const seen = new Set(
      allEntries.map((e) => e._normalizedLink || normalizeLink(e.link)),
    );
    for (const entry of newEntries) {
      entry._normalizedLink = normalizeLink(entry.link);
      const key = entry._normalizedLink;
      if (key && !seen.has(key)) {
        seen.add(key);
        allEntries.push(entry);
      } else if (!key) {
        allEntries.push(entry);
      }
    }
    sortEntries();
  }

  function applyFilter() {
    const query = searchInput.value.trim().toLowerCase();
    const fromVal = dateFromInput.value;
    const toVal = dateToInput.value;
    const dateFrom = fromVal ? new Date(fromVal).toISOString() : null;
    const dateTo = toVal ? new Date(toVal).toISOString() : null;

    filteredEntries = allEntries.filter((e) => {
      if (disabledUrls.has(e.feedUrl)) return false;
      if (dateFrom && (!e.pubDate || e.pubDate < dateFrom)) return false;
      if (dateTo && (!e.pubDate || e.pubDate > dateTo)) return false;
      if (!query) return true;
      return (
        e.title.toLowerCase().includes(query) ||
        e.link.toLowerCase().includes(query)
      );
    });

    if (dedupeCheckbox.checked) {
      const seen = new Set();
      filteredEntries = filteredEntries.filter((e) => {
        const key =
          (e._normalizedLink || "") +
          "\0" +
          (e.title || "").trim().toLowerCase();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
    }

    renderPage();
  }

  function renderPage() {
    const totalPages = Math.max(
      1,
      Math.ceil(filteredEntries.length / PAGE_SIZE),
    );
    if (currentPage > totalPages) currentPage = totalPages;

    const pageEntries = getCurrentPageEntries();

    const frag = document.createDocumentFragment();
    for (const entry of pageEntries) {
      const tr = document.createElement("tr");
      const normalized = entry._normalizedLink || "";

      if (normalized && visitedLinks.has(normalized)) {
        tr.className = "visited";
      }

      const tdDate = document.createElement("td");
      tdDate.className = "cell-date";
      if (entry.pubDate) {
        const d = new Date(entry.pubDate);
        tdDate.textContent = d.toLocaleString(undefined, {
          year: "numeric",
          month: "short",
          day: "numeric",
          hour: "2-digit",
          minute: "2-digit",
        });
      }

      const tdTitle = document.createElement("td");
      tdTitle.className = "cell-title";
      if (entry.link) {
        const a = document.createElement("a");
        a.href = entry.link;
        a.target = "_blank";
        a.rel = "noopener noreferrer";
        a.className = "entry-link";
        a.textContent = entry.title;
        if (normalized) a.dataset.normalized = normalized;
        tdTitle.appendChild(a);

        const btnWrap = document.createElement("span");
        btnWrap.className = "summarize-buttons";

        for (const svc of AI_SERVICES) {
          if (!enabledAiServices.includes(svc.id)) continue;
          const btn = document.createElement("a");
          btn.href = svc.urlTemplate.replace(
            "{article_url}",
            encodeURIComponent(entry.link),
          );
          btn.target = "_blank";
          btn.rel = "noopener noreferrer";
          btn.className = "summarize-btn " + svc.id;
          btn.textContent = svc.shortLabel;
          btn.title = "Summarize with " + svc.label;
          btn.style.background = svc.bg;
          btn.style.color = svc.fg;
          btnWrap.appendChild(btn);
        }

        tdTitle.appendChild(btnWrap);
      } else {
        tdTitle.textContent = entry.title;
      }

      const tdUrl = document.createElement("td");
      tdUrl.className = "cell-url";
      tdUrl.textContent = entry.link || "";
      tdUrl.title = entry.link || "";

      tr.appendChild(tdDate);
      tr.appendChild(tdTitle);
      tr.appendChild(tdUrl);
      frag.appendChild(tr);
    }

    entriesBody.textContent = "";
    entriesBody.appendChild(frag);
    renderPagination(totalPages);
  }

  function getCurrentPageEntries() {
    const start = (currentPage - 1) * PAGE_SIZE;
    return filteredEntries.slice(start, start + PAGE_SIZE);
  }

  function renderPagination(totalPages) {
    paginationTop.textContent = "";
    paginationBottom.textContent = "";
    if (totalPages <= 1) return;

    for (const container of [paginationTop, paginationBottom]) {
      const addBtn = (label, page, isActive) => {
        const btn = document.createElement("button");
        btn.textContent = label;
        if (isActive) btn.className = "active";
        btn.dataset.page = page;
        container.appendChild(btn);
      };

      if (currentPage > 1) {
        addBtn("\u00ab\u00ab First", 1, false);
        addBtn("\u00ab Prev", currentPage - 1, false);
      }

      let start = Math.max(1, currentPage - 4);
      let end = Math.min(totalPages, start + 8);
      start = Math.max(1, end - 8);

      for (let p = start; p <= end; p++) {
        addBtn(String(p), p, p === currentPage);
      }

      if (currentPage < totalPages) {
        addBtn("Next \u00bb", currentPage + 1, false);
        addBtn("Last \u00bb\u00bb", totalPages, false);
      }
    }
  }

  async function renderFeedsList() {
    const feeds = await Storage.getFeeds();
    feedsList.textContent = "";
    noFeedsMsg.style.display = feeds.length === 0 ? "block" : "none";

    for (const feed of feeds) {
      const li = document.createElement("li");
      if (feed.enabled === false) li.className = "disabled";

      const span = document.createElement("span");
      span.textContent = feed.title || feed.url;
      span.title = feed.url;
      span.addEventListener("click", async () => {
        await Storage.toggleFeed(feed.url);
        await updateDisabledUrls();
        await renderFeedsList();
        applyFilter();
      });

      const btn = document.createElement("button");
      btn.textContent = "\u00d7";
      btn.title = "Remove feed";
      btn.addEventListener("click", async () => {
        await Storage.removeFeed(feed.url);
        allEntries = allEntries.filter((e) => e.feedUrl !== feed.url);
        await Storage.saveCachedEntries(allEntries);
        await updateDisabledUrls();
        applyFilter();
        await renderFeedsList();
        setStatus("Removed feed");
      });

      li.appendChild(span);
      li.appendChild(btn);
      feedsList.appendChild(li);
    }
  }

  function readFileAsText(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsText(file);
    });
  }

  function setStatus(msg) {
    statusBar.textContent = msg;
  }

  function setProgress(fraction) {
    progressFill.style.width = Math.round(fraction * 100) + "%";
  }
})();

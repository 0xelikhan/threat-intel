"use strict";

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.target !== "offscreen-feed-parser") {
    return false;
  }

  if (message.type === "ping") {
    sendResponse({ ok: true });
    return false;
  }

  if (message.type !== "parse-feed") {
    return false;
  }

  try {
    const entries = FeedParser.parse(message.xmlString, message.feedUrl);
    sendResponse({ ok: true, entries });
  } catch (err) {
    sendResponse({ ok: false, error: err.message });
  }

  return false;
});

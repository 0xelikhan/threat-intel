Browser extension to collect articles through RSS feeds.

Features include OPML import and export, feed enable/disable controls, cached entries, and Chromium-compatible scheduled auto-refresh.

## Chromium 1.2.2 parser-response fix

- Prevents popup and reader message listeners from returning promises for unrelated messages.
- Adds an offscreen parser readiness handshake before the first parse request.
- Avoids the `Offscreen feed parser did not respond` response race in Chromium.

importScripts(
  "lib/browser-polyfill.js",
  "lib/ai-services.js",
  "lib/storage.js",
);

const CONCURRENT_LIMIT = 5;
const AUTO_REFRESH_ALARM = "notreadinallthat-auto-refresh";
const OFFSCREEN_DOCUMENT_PATH = "offscreen/offscreen.html";

let bgRefreshing = false;
let creatingOffscreenDocument = null;
let offscreenReadyPromise = null;

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitForOffscreenDocumentReady() {
  let lastError = null;

  for (let attempt = 0; attempt < 10; attempt += 1) {
    try {
      const response = await browser.runtime.sendMessage({
        target: "offscreen-feed-parser",
        type: "ping",
      });
      if (response?.ok) return;
      lastError = new Error("Offscreen parser returned no readiness response");
    } catch (err) {
      lastError = err;
    }

    await delay(50 * (attempt + 1));
  }

  throw new Error(
    "Offscreen feed parser failed to initialize" +
      (lastError?.message ? ": " + lastError.message : ""),
  );
}

async function ensureOffscreenDocument() {
  const offscreenUrl = chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH);
  let documentExists = false;

  if ("getContexts" in chrome.runtime) {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [offscreenUrl],
    });
    documentExists = contexts.length > 0;
  } else {
    const matchedClients = await clients.matchAll();
    documentExists = matchedClients.some((client) => client.url === offscreenUrl);
  }

  if (!documentExists) {
    if (!creatingOffscreenDocument) {
      creatingOffscreenDocument = chrome.offscreen.createDocument({
        url: OFFSCREEN_DOCUMENT_PATH,
        reasons: ["DOM_PARSER"],
        justification: "Parse RSS and Atom XML returned by configured feeds",
      });
    }

    try {
      await creatingOffscreenDocument;
    } finally {
      creatingOffscreenDocument = null;
    }
  }

  if (!offscreenReadyPromise) {
    offscreenReadyPromise = waitForOffscreenDocumentReady();
  }

  try {
    await offscreenReadyPromise;
  } finally {
    offscreenReadyPromise = null;
  }
}

async function parseFeed(xmlString, feedUrl) {
  await ensureOffscreenDocument();
  const response = await browser.runtime.sendMessage({
    target: "offscreen-feed-parser",
    type: "parse-feed",
    xmlString,
    feedUrl,
  });

  if (!response || !response.ok) {
    throw new Error(
      response?.error ||
        "Offscreen feed parser did not respond. Check extension message listeners.",
    );
  }
  return response.entries || [];
}

async function fetchFeed(url) {
  try {
    const resp = await fetch(url);
    if (!resp.ok) throw new Error("HTTP " + resp.status);
    const text = await resp.text();
    return await parseFeed(text, url);
  } catch (err) {
    console.warn("Background: failed to fetch " + url + ": " + err.message);
    return [];
  }
}

async function fetchFeedsBatched(urls) {
  const results = [];
  for (let i = 0; i < urls.length; i += CONCURRENT_LIMIT) {
    const batch = urls.slice(i, i + CONCURRENT_LIMIT);
    const batchResults = await Promise.allSettled(
      batch.map((url) => fetchFeed(url)),
    );
    for (const result of batchResults) {
      if (result.status === "fulfilled") {
        results.push(...result.value);
      }
    }
  }
  return results;
}

function normalizeLink(link) {
  if (!link) return "";
  try {
    const url = new URL(link);
    url.hash = "";
    for (const parameter of [
      "utm_source",
      "utm_medium",
      "utm_campaign",
      "utm_term",
      "utm_content",
    ]) {
      url.searchParams.delete(parameter);
    }
    return url.toString().replace(/\/+$/, "").toLowerCase();
  } catch {
    return link.trim().replace(/\/+$/, "").toLowerCase();
  }
}

async function backgroundRefresh() {
  if (bgRefreshing) return;
  bgRefreshing = true;

  try {
    const feeds = await Storage.getFeeds();
    const enabledFeeds = feeds.filter((feed) => feed.enabled !== false);
    if (enabledFeeds.length === 0) return;

    console.log(
      "Background: auto-refresh starting for " + enabledFeeds.length + " feeds",
    );

    const newEntries = await fetchFeedsBatched(
      enabledFeeds.map((feed) => feed.url),
    );

    const seen = new Set();
    const deduped = [];
    for (const entry of newEntries) {
      const key = normalizeLink(entry.link);
      if (key && !seen.has(key)) {
        seen.add(key);
        deduped.push(entry);
      } else if (!key) {
        deduped.push(entry);
      }
    }

    deduped.sort((a, b) => {
      if (!a.pubDate && !b.pubDate) return 0;
      if (!a.pubDate) return 1;
      if (!b.pubDate) return -1;
      return b.pubDate.localeCompare(a.pubDate);
    });

    await Storage.saveCachedEntries(deduped);

    browser.runtime
      .sendMessage({ type: "background-refresh-done" })
      .catch(() => {});

    console.log(
      "Background: refreshed " +
        deduped.length +
        " entries from " +
        enabledFeeds.length +
        " feeds",
    );
  } catch (err) {
    console.error("Background: auto-refresh failed: " + err.message);
  } finally {
    bgRefreshing = false;
  }
}

async function scheduleAutoRefresh() {
  await browser.alarms.clear(AUTO_REFRESH_ALARM);

  const settings = await Storage.getAutoRefresh();
  if (!settings.enabled) {
    console.log("Background: auto-refresh disabled");
    return;
  }

  const intervalMinutes = Math.max(
    1,
    Number(settings.intervalMinutes) || 60,
  );

  await browser.alarms.create(AUTO_REFRESH_ALARM, {
    delayInMinutes: intervalMinutes,
    periodInMinutes: intervalMinutes,
  });

  console.log(
    "Background: auto-refresh scheduled every " + intervalMinutes + " min",
  );
}

browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === AUTO_REFRESH_ALARM) {
    backgroundRefresh();
  }
});

browser.runtime.onMessage.addListener((message) => {
  if (message.type === "auto-refresh-changed") {
    scheduleAutoRefresh().catch((err) => {
      console.error("Background: failed to reschedule auto-refresh: " + err.message);
    });
  }
});

browser.runtime.onInstalled.addListener(() => {
  scheduleAutoRefresh().catch((err) => {
    console.error("Background: failed to initialize auto-refresh: " + err.message);
  });
});

browser.runtime.onStartup.addListener(() => {
  scheduleAutoRefresh().catch((err) => {
    console.error("Background: failed to restore auto-refresh: " + err.message);
  });
});

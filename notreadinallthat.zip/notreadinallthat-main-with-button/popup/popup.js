(async function () {
  "use strict";

  const PAGE_SIZE = 5;
  let entries = [];
  let currentPage = 1;

  const entriesDiv = document.getElementById("entries");
  const pagination = document.getElementById("pagination");
  const emptyMsg = document.getElementById("empty");
  const themeToggleBtn = document.getElementById("theme-toggle");

  const THEMES = ["light", "dark", "classic", "oled"];
  const THEME_ICONS = {
    light: "\u263E",
    dark: "\u2600",
    classic: "\u263E",
    oled: "\u2600",
  };

  const savedTheme = await browser.storage.local.get("theme");
  let currentTheme = savedTheme.theme || "light";
  if (!THEMES.includes(currentTheme)) currentTheme = "light";
  applyTheme(currentTheme);

  themeToggleBtn.addEventListener("click", async () => {
    const idx = THEMES.indexOf(currentTheme);
    currentTheme = THEMES[(idx + 1) % THEMES.length];
    applyTheme(currentTheme);
    await browser.storage.local.set({ theme: currentTheme });
  });

  function applyTheme(theme) {
    document.body.classList.remove("dark", "classic", "oled");
    if (theme !== "light") document.body.classList.add(theme);
    themeToggleBtn.textContent = THEME_ICONS[theme];
    themeToggleBtn.title = "Theme: " + theme;
  }

  document.getElementById("open-all-unread").addEventListener("click", async () => {
    const unreadEntries = getCurrentPageEntries().filter((entry) => {
      const normalized = normalizeLink(entry.link);
      return entry.link && normalized && !visitedLinks.has(normalized);
    });

    if (unreadEntries.length === 0) {
      return;
    }

    for (const entry of unreadEntries) {
      await browser.tabs.create({ url: entry.link, active: false });
      const normalized = normalizeLink(entry.link);
      if (normalized) {
        visitedLinks.add(normalized);
        await Storage.addVisitedLink(normalized);
      }
    }
    window.close();
  });

  document.getElementById("open-full").addEventListener("click", async () => {
    const readerUrl = browser.runtime.getURL("reader/reader.html");
    const tabs = await browser.tabs.query({ url: readerUrl });

    if (tabs.length > 0) {
      await browser.tabs.update(tabs[0].id, { active: true });
      await browser.windows.update(tabs[0].windowId, { focused: true });
    } else {
      await browser.tabs.create({ url: readerUrl });
    }
    window.close();
  });

  const enabledAiServices = await Storage.getEnabledAiServices();
  const visitedLinks = await Storage.getVisitedLinks();
  const allEntries = await Storage.getCachedEntries();
  const feeds = await Storage.getFeeds();
  const disabledUrls = new Set(
    feeds.filter((f) => f.enabled === false).map((f) => f.url),
  );

  const now = new Date();
  const dateFrom = new Date(
    now.getTime() - 3 * 24 * 60 * 60 * 1000,
  ).toISOString();
  const dateTo = new Date(
    now.getTime() + 1 * 24 * 60 * 60 * 1000,
  ).toISOString();

  function normalizeLink(link) {
    if (!link) return "";
    try {
      const u = new URL(link);
      u.hash = "";
      for (const p of [
        "utm_source",
        "utm_medium",
        "utm_campaign",
        "utm_term",
        "utm_content",
      ]) {
        u.searchParams.delete(p);
      }
      return u.toString().replace(/\/+$/, "").toLowerCase();
    } catch {
      return link.trim().replace(/\/+$/, "").toLowerCase();
    }
  }

  entries = allEntries.filter((e) => {
    if (disabledUrls.has(e.feedUrl)) return false;
    if (!e.pubDate || e.pubDate < dateFrom || e.pubDate > dateTo) return false;
    return true;
  });

  if (entries.length === 0) {
    emptyMsg.style.display = "block";
  } else {
    renderPage();
  }

  browser.runtime.onMessage.addListener((message) => {
    if (message.type !== "background-refresh-done") {
      return false;
    }

    void (async () => {
      const refreshed = await Storage.getCachedEntries();
      entries = refreshed.filter((e) => {
        if (disabledUrls.has(e.feedUrl)) return false;
        if (!e.pubDate || e.pubDate < dateFrom || e.pubDate > dateTo)
          return false;
        return true;
      });
      if (entries.length === 0) {
        emptyMsg.style.display = "block";
        entriesDiv.textContent = "";
        pagination.textContent = "";
      } else {
        emptyMsg.style.display = "none";
        currentPage = 1;
        renderPage();
      }
    })().catch((err) => {
      console.error("Popup: failed to apply background refresh: " + err.message);
    });

    return false;
  });

  function renderPage() {
    const totalPages = Math.max(1, Math.ceil(entries.length / PAGE_SIZE));
    if (currentPage > totalPages) currentPage = totalPages;

    const pageEntries = getCurrentPageEntries();

    entriesDiv.textContent = "";
    for (const entry of pageEntries) {
      const div = document.createElement("div");
      const normalized = normalizeLink(entry.link);
      div.className = "entry";
      if (normalized && visitedLinks.has(normalized)) {
        div.classList.add("visited");
      }

      const a = document.createElement("a");
      a.href = entry.link || "#";
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.textContent = entry.title || "(no title)";
      a.title = entry.link || "";
      a.addEventListener("click", () => {
        if (normalized) {
          visitedLinks.add(normalized);
          div.classList.add("visited");
          Storage.addVisitedLink(normalized);
        }
      });
      div.appendChild(a);

      if (entry.link) {
        const btnWrap = document.createElement("span");
        btnWrap.className = "summarize-buttons";

        for (const svc of AI_SERVICES) {
          if (!enabledAiServices.includes(svc.id)) continue;
          const btn = document.createElement("a");
          btn.href = svc.urlTemplate.replace(
            "{article_url}",
            encodeURIComponent(entry.link),
          );
          btn.target = "_blank";
          btn.rel = "noopener noreferrer";
          btn.className = "summarize-btn " + svc.id;
          btn.textContent = svc.shortLabel;
          btn.title = "Summarize with " + svc.label;
          btn.style.background = svc.bg;
          btn.style.color = svc.fg;
          btnWrap.appendChild(btn);
        }

        div.appendChild(btnWrap);
      }

      if (entry.pubDate) {
        const date = document.createElement("div");
        date.className = "date";
        date.textContent = new Date(entry.pubDate).toLocaleDateString(
          undefined,
          {
            year: "numeric",
            month: "short",
            day: "numeric",
          },
        );
        div.appendChild(date);
      }

      entriesDiv.appendChild(div);
    }

    renderPagination(totalPages);
  }

  function getCurrentPageEntries() {
    const start = (currentPage - 1) * PAGE_SIZE;
    return entries.slice(start, start + PAGE_SIZE);
  }

  function renderPagination(totalPages) {
    pagination.textContent = "";
    if (totalPages <= 1) return;

    const addBtn = (label, page, isActive) => {
      const btn = document.createElement("button");
      btn.textContent = label;
      if (isActive) btn.className = "active";
      btn.addEventListener("click", () => {
        currentPage = page;
        renderPage();
      });
      pagination.appendChild(btn);
    };

    if (currentPage > 1) {
      addBtn("\u00ab\u00ab", 1, false);
      addBtn("\u00ab", currentPage - 1, false);
    }

    let start = Math.max(1, currentPage - 2);
    let end = Math.min(totalPages, start + 4);
    start = Math.max(1, end - 4);

    for (let p = start; p <= end; p++) {
      addBtn(String(p), p, p === currentPage);
    }

    if (currentPage < totalPages) {
      addBtn("\u00bb", currentPage + 1, false);
      addBtn("\u00bb\u00bb", totalPages, false);
    }
  }
})();
